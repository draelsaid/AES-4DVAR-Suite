%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Program to perform 4D-Var data assimilation on the
% Lorenz equations
%
%
%  (c) 2002  Data Assimilation Research Centre
%
%  Original Fortran program by Marek Wlasak
%  Converted to Matlab by Amos Lawless
%
%  Change history:
%      Changes to make code more robust and add further options
%                       (Amos Lawless)
%      16/03/04  Corrections to code
%                Remove high memory allocations
%                Ensure windows appear in correct place
%                       (Amos Lawless)
%
%                Replace Steepest Descent by CG
%
%  List of main variables
%    a:          sigma coefficient in equations
%    r:          rho coefficient in equations
%    b:          beta coefficient in equations
%
%    ta:         Length of assimilation window
%    tf:         Length of forecast window
%    h:          Time step for numerical scheme
%    freq:       Frequency of observations in time steps
%    tstep:      Number of time steps for assimilation
%    fcstep:     Total number of time steps for assimilation + forecast
%
%    [xx,yy,zz]: Truth values of trajectory
%    [xf,yf,zf]: First guess values of trajectory
%    [x,y,z]:    Calculated values of trajectory and final analysis
%    [lx,ly,lz]: Gradient values calculated from adjoint
%
%    [datx,daty,datz]: Observation values
%    D:                Observation weighting matrix
%    max_iterations:   Maximum number of minimization iterations
%    tolerance:        Convergence tolerance for minimization
%    s:                Calculated step length in minimization
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%---------------------------------------------------------------------
%   1. Set up
%---------------------------------------------------------------------
% Close any open figure windows
close all
clear
% Determine screen size and set up figure positions
ss=get(0,'ScreenSize');
fig_width=0.55*ss(3);
fig_height=0.4*ss(4);
pos_1=[0.02*ss(3),0.55*ss(4),fig_width,fig_height];
pos_2=[0.02*ss(3),0.05*ss(4),fig_width,fig_height];
pos_3=[0.6*ss(3),0.45*ss(4),0.4*ss(3),0.45*ss(4)];
pl=0.6*ss(3);
pb=0.05*ss(4);
pw=0.3*ss(3);
ph=0.35*ss(4);
pos_4=[pl,pb,pw,ph];
pos_5=[0.02*pw,0.8*ph,0.95*pw,0.2*ph];
pos_6=[0.02*pw,0.02*ph,0.95*pw,0.75*ph];
%
format long
%parameters
a=1.0d1;       % sigma
b=8.0d0/3.0d0; % rho
r=2.8d1;       % beta
%
%---------------------------------------------------------------------
%  2. Input truth parameters and calculate truth
%---------------------------------------------------------------------
% Inputs 1
xstr='True value of x at t=0';
ystr='True value of y at t=0';
zstr='True value of z at t=0';
true_str=inputdlg({xstr,ystr,zstr},'Initial data');
truex=str2num(true_str{1});
truey=str2num(true_str{2});
truez=str2num(true_str{3});

% Inputs 2
xstr='Length of assimilation window';
x2str='Length of subsequent forecast';
ystr='Time step';
zstr='Frequency of observations (in time steps)';
temp_str=inputdlg({xstr,x2str,ystr,zstr},'Run information');
ta=str2num(temp_str{1});
tf=str2num(temp_str{2});
h=str2num(temp_str{3});
freq=str2num(temp_str{4});

tstep = ta/h+1;
fcstep = (ta+tf)/h;

% Run truth
guessx(1)=truex;
guessy(1)=truey;
guessz(1)=truez;
j=0;
[xx,yy,zz]=modeuler(fcstep,h,j,guessz,guessy,guessx,a,r,b);

%---------------------------------------------------------------------
% 3. Calculate observations and plot truth and observations
%---------------------------------------------------------------------
D=zeros(tstep,1);
n_obs = floor((tstep-1) / freq) + 1;
datx=zeros(tstep,1);
daty=zeros(tstep,1);
datz=zeros(tstep,1);
x_d=zeros(tstep,1);
y_d=zeros(tstep,1);
z_d=zeros(tstep,1);
  sd_str=inputdlg('Variance of observation error');
  var=str2num(sd_str{1});
  sd=sqrt(var);
  read_noise=questdlg('Read in noise from file? (Assumes number of observations unchanged)','Yes','No')
  if strcmp(read_noise,'Yes') == 1
     load errors
     disp('Reading errors from file')
  else
     sc_x_noise=randn(n_obs,1);
     sc_y_noise=randn(n_obs,1);
     sc_z_noise=randn(n_obs,1);
     disp('Creating new errors')
  end  
    RX=sd*sc_x_noise;
    RY=sd*sc_y_noise;
    RZ=sd*sc_z_noise;
% Set up data and matrix D
j=1;
for i=1:freq:tstep
    datx(i)=xx(i)+RX(j);
    daty(i)=yy(i)+RY(j);
    datz(i)=zz(i)+RZ(j);
    D(i) = 1.;
    j=j+1;
end
% Plot truth and observations
xvals=0:fcstep;
vec=1:freq:tstep;
v=vec-1;
for i=vec
    x_ob(i)=datx(i);
    z_ob(i)=datz(i);
end
% x_ob and z_ob are temporary arrays for plotting
%
h1=figure('Position',pos_1);
clf;
subplot(2,1,1)
plot(xvals,xx)
hold on
plot(v,x_ob(vec),'om')
hold on
xlabel('Time step')
ylabel('x')
title('Solution for x')
legend('Truth','Observations')
%
subplot(2,1,2)
plot(xvals,zz)
hold on
plot(v,z_ob(vec),'om')
hold on
xlabel('Time step')
ylabel('z')
title('Solution for z')
legend('Truth','Observations')

%---------------------------------------------------------------------
% 4. Set up background field and run model from this
%---------------------------------------------------------------------


% modif : first guess now produced by Gaussian noise
sd_str=inputdlg('Variance of background error');
varb=str2num(sd_str{1});
sdb=sqrt(varb);
  if strcmp(read_noise,'No') == 1
    etab = sdb*randn(1,3);
  end
guessx(2)= truex + etab(1);
guessy(2)= truey + etab(2);
guessz(2)= truez + etab(3);


j=1;
 % Plot first guess
 [xf,yf,zf]=modeuler(fcstep,h,j,guessz,guessy,guessx,a,r,b);
 subplot(2,1,1)
 plot(xvals,xf,':')
 legend('Truth','Observations','Background')
 hold on
 subplot(2,1,2)
 plot(xvals,zf,':')
 legend('Truth','Observations','Background')
 hold on

save errors sc_x_noise sc_y_noise sc_z_noise etab
%---------------------------------------------------------------------
% 5. Input minimization info and perform minimization
%---------------------------------------------------------------------
xstr='Maximum number of iterations';
ystr='Epsilon (inner loop)';
y2str='Outer loops';
zstr={'30','1d-5','4'};
min_str=inputdlg({xstr,ystr,y2str},'Minimization control',1,zstr);
max_iterations=str2num(min_str{1});
crit3=str2num(min_str{2});
outer_loops=str2num(min_str{3});
%
k=1;
costplot=zeros(1);
normplot=zeros(1);

guessz_back = guessz;
guessy_back = guessy;
guessx_back = guessx;


k=1;
costplot_back = zeros(1);
normplot_back = zeros(1);

for i_outer=1:outer_loops
    %%%% Start of outer loop %%%%
    disp(['*** STARTING OUTER LOOP ' num2str(i_outer)])
    [x,y,z]=modeuler(tstep,h,i_outer,guessz_back,guessy_back,guessx_back,a,r,b);

    x0_p = 0.0d0;
    y0_p = 0.0d0;
    z0_p = 0.0d0;

    % Calculate innovations
    for i=1:freq:tstep
        x_d(i) = x(i) - datx(i);
        y_d(i) = y(i) - daty(i);
        z_d(i) = z(i) - datz(i);
    end

    X0_p = [x0_p,y0_p,z0_p];


    % modif
    % Calculate  background innovations
    x0_b = guessx_back(2) - guessx_back(i_outer+1);
    y0_b = guessy_back(2) - guessy_back(i_outer+1);
    z0_b = guessz_back(2) - guessz_back(i_outer+1);

    X0_b = [x0_b,y0_b,z0_b];

    [Xp JX dJX it] = minimize_mod_crit(X0_p','calcfg_inc',max_iterations,crit3,tstep,h,x,y,z,x_d,y_d,z_d,...
        a,r,b,D,freq,var,varb,X0_b');


    % modif
    guessx_back(i_outer+2) = guessx_back(i_outer+1) + Xp(1);
    guessy_back(i_outer+2) = guessy_back(i_outer+1) + Xp(2);
    guessz_back(i_outer+2) = guessz_back(i_outer+1) + Xp(3);

    j = size(JX);
    for i = 1 : j
        g =  dJX(:,i);
        lx=g(1);
        ly=g(2);
        lz=g(3);
        lnorm(i+1)=sqrt(lx(1)*lx(1)+ly(1)*ly(1)+lz(1)*lz(1));
    end

    costplot_back(k:k+j-1) = JX;
    normplot_back(k:k+j-1) = lnorm(2:j+1);
    k=k+j;

end  % i_outer

%---------------------------------------------------------------------
% 6. Run forecast from final analysis and plot
%---------------------------------------------------------------------
jtemp=0;
guessx_back(1)=guessx_back(i_outer+2);
guessy_back(1)=guessy_back(i_outer+2);
guessz_back(1)=guessz_back(i_outer+2);
[xb,yb,zb]=modeuler(fcstep,h,jtemp,guessz_back,guessy_back,guessx_back,a,r,b);

subplot(2,1,1)
plot(xvals,xb,'--r')
legend('Truth','Observations','Background','Analysis')
% Plot vertical line at start of forecast
yminmax=get(gca,'YLim');
yspace=(yminmax(2)-yminmax(1))*0.01;
yvals=yminmax(1):yspace:yminmax(2);
line(tstep-1,yvals,'LineStyle',':','Color','k')
hold off
%
subplot(2,1,2)
plot(xvals,zb,'--r')
legend('Truth','Observations','Background','Analysis')
% Plot vertical line at start of forecast
yminmax=get(gca,'YLim');
yspace=(yminmax(2)-yminmax(1))*0.01;
yvals=yminmax(1):yspace:yminmax(2);
line(tstep-1,yvals,'LineStyle',':','Color','k')
hold off

%---------------------------------------------------------------------
%  7. Calculate and plot error
%---------------------------------------------------------------------

x_error_back=xx-xb;
z_error_back=zz-zb;

h2=figure('Position',pos_2);
clf;
subplot(2,1,1)
xlabel('Time step');ylabel('Error')
title('Plot of error (Truth-Analysis) in x against time')
plot(xvals,x_error_back,'-b');
% Plot vertical line at start of forecast
yminmax=get(gca,'YLim');
yspace=(yminmax(2)-yminmax(1))*0.01;
yvals=yminmax(1):yspace:yminmax(2);
line(tstep-1,yvals,'LineStyle',':','Color','k')
%
hold on
subplot(2,1,2)
xlabel('Time step');ylabel('Error')
title('Plot of error (Truth-Analysis) in z against time')
plot(xvals,z_error_back,'-b');
% Plot vertical line at start of forecast
yminmax=get(gca,'YLim');
yspace=(yminmax(2)-yminmax(1))*0.01;
yvals=yminmax(1):yspace:yminmax(2);
line(tstep-1,yvals,'LineStyle',':','Color','k')

%-----------------------------------------------------------------------
%  8. Plot convergence
%---------------------------------------------------------------------
h3=figure('Position',pos_3);
clf;
xmax=max(size(normplot));
xvals=0:xmax-1;

xmax_back=max(size(normplot_back));
xvals_back=0:xmax_back-1;

subplot(2,1,1)
title('Convergence of cost function')
xlabel('Iteration')
ylabel('Cost function')
semilogy(xvals_back,costplot_back,'b')
subplot(2,1,2)
title('Convergence of gradient')
xlabel('Iteration')
ylabel('Norm of gradient')
semilogy(xvals_back,normplot_back,'b')
%-----------------------------------------------------------------------
% 9. Write out options chosen
%---------------------------------------------------------------------
h4=figure('Position',pos_4);
clf;
text1={'List of options chosen'};
text2={['True (x,y,z) at t=0:   (' true_str{1} ',' true_str{2} ',' ...
    true_str{3}  ')']};
%text3={['First guess (x,y,z) at t=0:   (' guess_str{1} ',' guess_str{2} ',' ...
%    guess_str{3}  ')']};
text4={['Length of assimilation window: ' temp_str{1}]};
text5={['Length of subsequent forecast: ' temp_str{2}]};
text6={['Time step: ' temp_str{3}]};
text7={['Frequency of observations = ' temp_str{4}]};
text9={['Maximum iterations: ' min_str{1}]};
text10={['Epsilon (inner loop) = ' min_str{2}]};
text11={['Observations : variance of noise = ' num2str(var)]};
text12={['Background : variance of noise = ' num2str(varb)]};

%str1=[text2;text3;text4;text5;text6;text7;text9;text10;text11];
str1=[text2;text4;text5;text6;text7;text9;text10;text11;text12];
uicontrol('Style','text','Position',pos_5,'String',text1,...
    'FontSize',14,'FontWeight','bold')
uicontrol('Style','text','Position',pos_6,'String',str1,...
    'FontSize',12,'HorizontalAlignment','left')
