function [f,g] = calcfg(X0,tstep,delta_t,datx,daty,datz, ...
    u_bg,a,r,b,Dx,Dy,Dz,obs_var, prior_var)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Purpose: Calculate full cost function and gradient
%           for 4D-Var, including background term
%
%  Written by Amos Lawless
%
%  List of main variables
%    a:          sigma coefficient in equations
%    r:          rho coefficient in equations
%    b:          beta coefficient in equations
%    D:          Observation weighting matrix
%    h:          Time step for numerical scheme
%    tstep:      Number of time steps to perform
%    [x,y,z]:    Current iterate
%    [datx,daty,datz]: Observation values
%
%  Output:
%    [f,g]: Cost function and gradient
%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x=zeros(tstep,1);
y=zeros(tstep,1);
z=zeros(tstep,1);
x(1)=X0(1);
y(1)=X0(2);
z(1)=X0(3);
f=0.0d0;
%
% Calculate cost function
  f = f + 0.5 * ( Dx(1)*(x(1)-datx(1))*(x(1)-datx(1)) ...
        + Dy(1)*(y(1)-daty(1))*(y(1)-daty(1)) ...
        + Dz(1)*(z(1)-datz(1))*(z(1)-datz(1)) ) / obs_var ...
        + 0.5 * ( (x(1)-u_bg(1))*(x(1)-u_bg(1)) ...
        + (y(1)-u_bg(2))*(y(1)-u_bg(2)) ...
        + (z(1)-u_bg(3))*(z(1)-u_bg(3)) ) / prior_var;

for i=2:tstep
  [xx,yy,zz] = modeuler(1,delta_t,0,z(i-1),y(i-1),x(i-1),a,r,b);
  x(i) = xx(2);
  y(i) = yy(2);
  z(i) = zz(2);
%   if D(i) == 1
      f = f + 0.5 * ( Dx(i)*(x(i)-datx(i))*(x(i)-datx(i)) ...
        + Dy(i)*(y(i)-daty(i))*(y(i)-daty(i)) ...
        + Dz(i)*(z(i)-datz(i))*(z(i)-datz(i)) ) / obs_var;
%   end 
end
%
% Calculate gradient of cost function
x_hat=zeros(tstep,1);
y_hat=zeros(tstep,1);
z_hat=zeros(tstep,1);
%
x_hat(tstep) = (x(tstep)-datx(tstep))*Dx(tstep) / obs_var;
y_hat(tstep) = (y(tstep)-daty(tstep))*Dy(tstep) / obs_var;
z_hat(tstep) = (z(tstep)-datz(tstep))*Dz(tstep) / obs_var;
%
for i=tstep-1:-1:1
  [x1_hat,y1_hat,z1_hat] = modeuler_adj(1,delta_t,0,z(i),y(i),x(i),...
               x_hat(i+1),y_hat(i+1),z_hat(i+1),a,r,b);
  x_hat(i) = x1_hat(1) + (x(i)-datx(i))*Dx(i) / obs_var;
  y_hat(i) = y1_hat(1) + (y(i)-daty(i))*Dy(i) / obs_var;
  z_hat(i) = z1_hat(1) + (z(i)-datz(i))*Dz(i) / obs_var;
end
x_hat(1) = x_hat(1) + (x(1)-u_bg(1)) / prior_var;
y_hat(1) = y_hat(1) + (y(1)-u_bg(2)) / prior_var;
z_hat(1) = z_hat(1) + (z(1)-u_bg(3)) / prior_var;

g=[x_hat(1),y_hat(1),z_hat(1)]';

