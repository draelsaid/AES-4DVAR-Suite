function test_grad
format long
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Purpose: To test gradient of cost function
%
%  (c) 2004  Data Assimilation Research Centre
%
%  Written  by Amos Lawless
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
a=1.0d1;       % sigma
b=8.0d0/3.0d0; % rho
r=2.8d1;       % beta
h=0.01d0;        % time step
tstep=20;     % Number of steps
freq=2;
len=12;
obs_var=0.5;
prior_var=0.25;
x=zeros(tstep+1,1);
y=zeros(tstep+1,1);
z=zeros(tstep+1,1);
alpha_vec=zeros(len,1);
fn_vec=zeros(len,1);
resid_vec=zeros(len,1);
x(1)=1.0d0;
y(1)=1.0d0;
z(1)=1.0d0;
X0_b=[1.1,1.2,1.15]';
tstep=tstep+1;
%
% Set up data and matrix D
%
[x,y,z]=modeuler(tstep,h,0,z,y,x,a,r,b);
D=zeros(tstep,1);
n_obs = (tstep-1) / freq + 1;
datx=zeros(n_obs,1);
daty=zeros(n_obs,1);
datz=zeros(n_obs,1);
for i=1:freq:tstep
  datx(i)=x(i);
  daty(i)=y(i);
  datz(i)=z(i);
  D(i) = 1.;
end   
%
      x_vec = rand(1,6);
% Make x_vec order one
      scalar1 = 0.0D0;
      for i=1:3
        scalar1 = scalar1 + x_vec(i)*x_vec(i);
      end
      scalar1 = 1.0D0 / sqrt(scalar1);
      for i=1:3
        x_vec(i) = x_vec(i) * scalar1;
      end
%

      x(1) = x_vec(1);
      y(1) = x_vec(2);
      z(1) = x_vec(3);
      x0_p(1) = x_vec(4);
      y0_p(1) = x_vec(5);
      z0_p(1) = x_vec(6);
      [x,y,z]=modeuler(tstep,h,0,z,y,x,a,r,b);
% Calculate innovations
      for i=1:freq:tstep
        x_d(i) = x(i) - datx(i);
        y_d(i) = y(i) - daty(i);
        z_d(i) = z(i) - datz(i);
      end
      X0_p=[x0_p,y0_p,z0_p]';
      [f1,grad1] = calcfg_inc(X0_p,tstep,h,x,y,z,x_d,y_d,z_d,...
                     a,r,b,D,freq,obs_var,prior_var,X0_b);
      scalar1 = 0.0D0;
      for i=1:3
        scalar1 = scalar1 + grad1(i)*grad1(i);
      end
      scalar1 = 1.0D0 / sqrt(scalar1);
      for i=1:3
        h_vec(i) = grad1(i) * scalar1;
      end

      alpha = 1.0D0;

      for i_count=1:len
%
      x0_p(1) = x_vec(4) + alpha*h_vec(1);
      y0_p(1) = x_vec(5) + alpha*h_vec(2);
      z0_p(1) = x_vec(6) + alpha*h_vec(3);
%%      [x,y,z]=modeuler(tstep,h,0,z,y,x,a,r,b);
      X0_p=[x0_p,y0_p,z0_p]';
      [f2,grad2] = calcfg_inc(X0_p,tstep,h,x,y,z,x_d,y_d,z_d,...
                     a,r,b,D,freq,obs_var,prior_var,X0_b);
%
      scalar1 = 0.0D0;
      for i=1:3
        scalar1 = scalar1 + h_vec(i) * grad1(i);
      end
      scalar1 = (f2 - f1)/ (alpha*scalar1);
      scalar2 = abs(scalar1 - 1.0D0);
%
      alpha_vec(i_count) = alpha;
      fn_vec(i_count) = scalar1;
      resid_vec(i_count) = scalar2;
      alpha = alpha * 1.0D-1;

      end % i_count

% Produce plots
h=semilogx(alpha_vec,fn_vec);
title('Verification of gradient calculation')
xlabel('\alpha')
ylabel('\Phi(\alpha)')
%
figure(2)
loglog(alpha_vec,resid_vec)
title('Variation of residual')
xlabel('\alpha')
ylabel('\Phi(\alpha)-1')

