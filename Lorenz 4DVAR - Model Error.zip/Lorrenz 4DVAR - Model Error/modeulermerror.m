function [xo,yo,zo]=modeulermerror(tstep,h,j,zval,yval,xval,a,r,b,error_var)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Purpose: Apply modified Euler scheme to the Lorenz equations
%
%  (c) 2002  Data Assimilation Research Centre
%
%  Original Fortran program by Marek Wlasak
%  Converted to Matlab by Amos Lawless
%
%  6/7/04 Moved all functions inline to make adjoint easier
%
%  List of main variables
%    a:          sigma coefficient in equations
%    r:          rho coefficient in equations
%    b:          beta coefficient in equations
%    h:          Time step for numerical scheme
%    tstep:      Number of time steps to perform
%    [xval,yval,zval]: Initial fields
%    j:          Index to pick up correct initial field
%
%  Output:
%    [xo,yo,zo]: Trajectories of evolved fields
%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This module calls the modeuler module but with the slight modification
% of adding model error in the form of gaussian noise (normal
% distribution), with standard deviation equal to 'error_var', and xIn is
% the mean. would like to get user input on the var via a dialogue and see
% how it goes from there. the mean is fixed, as it will be the value that
% comes from modeuler



%m_error=

[xo,yo,zo]=modeuler(tstep,h,j,zval,yval,xval,a,r,b);

xo=calculateError(xo,error_var);

yo=calculateError(yo,error_var);

zo=calculateError(zo,error_var);

function x = calculateError(xIn,error_var)

    x=(random('norm',xIn,error_var));
end

end
%

