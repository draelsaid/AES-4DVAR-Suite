function [kappaSp,kappaPSp,kappaD] = HessNumCondNoCalc(n,N,fcD,fcR,fcM,obs_f_x,mlvl)

% Cost function matrices
O = zeros(N,N); I = eye(N);

% D Matrix
[Dinv{1:n+1,1:n+1}] = deal(O); [rtD{1:n+1,1:n+1}] = deal(O);

[~,~,Binv,Qinv] = fcD(randn(N,1));
[~,~,Rinv] = fcR(rand(N,n+1)); sigma_o = (1/Rinv(1,1))^0.5;

Dinv{1,1} = Binv;
rtD{1,1} = inv(Binv)^0.5;

for i=2:n+1
      Dinv{i,i} = Qinv;
       rtD{i,i} = inv(Qinv)^0.5;
end
rtD = cell2mat(rtD);
Dinv = cell2mat(Dinv);
M = fcM()^mlvl;            % Model in matrix form (must be LINEAR OR LINEARISED)

%%%%%%%%%%%%%%%%%%%%%%%%%% L, Linv, H, H^T %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[L{1:n+1,1:n+1}] = deal(O);
for i=1:n+1
    L{i,i} = I;
end

for i=2:n+1
L{i,i-1} = -M;
end

L = cell2mat(L);

[Linv{1:n+1,1:n+1}] = deal(O);
for i=1:n+1
  for j=1:i
    Linv{i,j} = M^(i-j);
  end
end
Linv = cell2mat(Linv);

h=zeros(obs_f_x,N); j=1; 
  for i=1:obs_f_x:N
    h(j,i) = 1;
    j=j+1;
  end

[H{1:n+1,1:n+1}] = deal(zeros(size(h)));
  for j=1:n+1
    H{j,j} = h;
  end
H = cell2mat(H);

%% Hessians
G = Linv'*H'*H*Linv;

Sp = Dinv + sigma_o^(-2)*G;                       % p formulation Hessian
PSp = eye(size(H'*H)) + sigma_o^(-2)*(rtD*G*rtD); % precond p formulation Hessian
Sx = L'*Dinv*L + sigma_o^(-2)*H'*H;               % x formulation Hessian

% Condition number calculations
kappaSp = cond(Sp);
kappaPSp = cond(PSp);
%kappaSx = cond(Sx);
kappaD = cond(Dinv);
end

