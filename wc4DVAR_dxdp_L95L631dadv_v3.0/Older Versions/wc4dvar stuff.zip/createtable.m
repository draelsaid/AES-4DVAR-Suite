f = figure('Position',[440 500 461 146]);

% create the data
d(:,1) = storeitdp;
d(:,2) = storeitdx;

d(:,3) = storeerrdp;
d(:,4) = storeerrdx;

d(:,5) = storekappaSx;
d(:,6) = storekappaSp;
d(:,7) = storekappaD;
d(:,8) = storehesssize;

d(:,9) = sigmabsigmaq;
d(:,10) = sigmabsigmao;
d(:,11) = sigmaqsigmao;

d(all(d==0,2),:)=[]
% Create the column and row names in cell arrays 
cnames = {'Jpit','Jperr','Jxit','Jxerr','sbsq','sbso','sqso'};

% Create the uitable
t = uitable(f,'Data',d,...
            'ColumnName',cnames);